import sys
import os
import re

print 'Pathogenic vcf'
a="grep -E 'CLINSIG=pathogenic|CLINSIG=probable-pathogenic' phased_variants.snps.hg19_multianno.txt >phased_variants.snps.hg19_multianno_pathogenic"
os.system(a)
aa="grep -v -E '10X_HOMOPOLYMER_UNPHASED_INSERTION|10X_RESCUED_MOLECULE_HIGH_DIVERSITY'  phased_variants.snps.hg19_multianno_pathogenic >phased_variants.hg19_multianno_pathogenic.vcf.annotation"
os.system(aa)

print 'Germline vcf'
b="python get_germline.py phased_variants.snps.hg19_multianno.txt phased_variants.snps.hg19_multianno_germline"
os.system(b)
f="grep -v -E '10X_HOMOPOLYMER_UNPHASED_INSERTION|10X_RESCUED_MOLECULE_HIGH_DIVERSITY' phased_variants.snps.hg19_multianno_germline >phased_variants.hg19_multianno_germline.vcf.annotation"
os.system(f)

print 'Somatic vcf'
ff="grep -v -E 'CLINSIG=pathogenic|CLINSIG=probable-pathogenic' phased_variants.snps.hg19_multianno.txt >phased_variants.snps.hg19_multianno_RMpathogenic"
os.system(ff)
g="grep -v '\<rs' phased_variants.snps.hg19_multianno_RMpathogenic >phased_variants.snps.hg19_multianno_RMpathogenic_RMrs"
os.system(g)
h="python RM_germline.py phased_variants.snps.hg19_multianno_RMpathogenic_RMrs phased_variants.snps.hg19_multianno_RMpathogenic_RMrs_RMgermline"
os.system(h)
i="grep -v -E '10X_HOMOPOLYMER_UNPHASED_INSERTION|10X_RESCUED_MOLECULE_HIGH_DIVERSITY' phased_variants.snps.hg19_multianno_RMpathogenic_RMrs_RMgermline >phased_variants.snps.hg19_multianno_RMpathogenic_RMrs_RMgermline_rmFP"
os.system(i)
j="grep -v -i -E '\<UTR3|\<UTR5|\<downstream|\<intergenic|\<intronic|\<ncRNA|\<upstream' phased_variants.snps.hg19_multianno_RMpathogenic_RMrs_RMgermline >phased_variants.snps.hg19_multianno_RMpathogenic_RMrs_RMgermline_exonic_splicing"
os.system(j)
k="grep -i -E '\<tert|\<sdhd|\<NFKBIE' phased_variants.snps.hg19_multianno_RMpathogenic_RMrs_RMgermline >Tert_sdhd_NFKBIE"
os.system(k)
l="grep -i -E -v '\<UTR3|\<UTR5|\<downstream|\<intergenic|\<intronic|\<ncRNA' Tert_sdhd_NFKBIE >Tert_sdhd_NFKBIE_upstream"
os.system(l)
m="cat phased_variants.snps.hg19_multianno_RMpathogenic_RMrs_RMgermline_exonic_splicing Tert_sdhd_NFKBIE_upstream >phased_variants.snps.hg19_multianno_RMpathogenic_RMrs_RMgermline_exonic_splicing_TSN"
os.system(m)
n="sort phased_variants.snps.hg19_multianno_RMpathogenic_RMrs_RMgermline_exonic_splicing_TSN |uniq >phased_variants.snps.hg19_multianno_RMpathogenic_RMrs_RMgermline_exonic_splicing_TSN_uniq"
os.system(n)
o="grep -v -E '10X_HOMOPOLYMER_UNPHASED_INSERTION|10X_RESCUED_MOLECULE_HIGH_DIVERSITY' phased_variants.snps.hg19_multianno_RMpathogenic_RMrs_RMgermline_exonic_splicing_TSN_uniq >phased_variants.snps.hg19_multianno_RMpathogenic_RMrs_RMgermline_exonic_splicing_TSN_uniq_RP"
os.system(o)
q='cat phased_variants.snps.hg19_multianno_RMpathogenic_RMrs_RMgermline_exonic_splicing_TSN_uniq_RP phased_variants.hg19_multianno_pathogenic.vcf.annotation >phased_variants.hg19_multianno_somatic.vcf.annotation'
os.system(q)
p='rm phased_variants.snps.hg19_multianno_pathogenic phased_variants.snps.hg19_multianno_germline phased_variants.snps.hg19_multianno_RMpathogenic phased_variants.snps.hg19_multianno_RMpathogenic_RMrs phased_variants.snps.hg19_multianno_RMpathogenic_RMrs_RMgermline phased_variants.snps.hg19_multianno_RMpathogenic_RMrs_RMgermline_rmFP phased_variants.snps.hg19_multianno_RMpathogenic_RMrs_RMgermline_exonic_splicing Tert_sdhd_NFKBIE Tert_sdhd_NFKBIE_upstream phased_variants.snps.hg19_multianno_RMpathogenic_RMrs_RMgermline_exonic_splicing_TSN phased_variants.snps.hg19_multianno_RMpathogenic_RMrs_RMgermline_exonic_splicing_TSN_uniq phased_variants.snps.hg19_multianno_RMpathogenic_RMrs_RMgermline_exonic_splicing_TSN_uniq_RP'
s.system(p)


