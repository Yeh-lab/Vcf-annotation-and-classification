#coding:utf-8

import sys
import re
import os

f1=open(sys.argv[1],'r')
f2=open(sys.argv[2],'w')
#f3=open(sys.argv[3],'w')

s={}
t={}
for i in f1:
    i=i.strip()
    h=i.split('	')
    m=re.match('Chr',i)
    if m is None:
      
      if h[15]=='' and h[23]=='' and h[24]=='':
          print >>f2,i
      if h[15]!='' and h[23]!='' and h[24]!='':
        if float(h[15])<0.001 and float(h[23])<0.001 and float(h[24])<0.001:
          print >>f2,i
      if h[15]=='' and h[23]!='' and h[24]!='':
        if float(h[23])<0.001 and float(h[24])<0.001:
          print >>f2,i
      if h[15]!='' and h[23]=='' and h[24]!='':
        if float(h[15])<0.001 and float(h[24])<0.001:
          print >>f2,i
      if h[15]!='' and h[23]!='' and h[24]=='':
        if float(h[15])<0.001 and float(h[23])<0.001:
          print >>f2,i
      if h[15]=='' and h[23]=='' and h[24]!='':
        if float(h[24])<0.001:
          print >>f2,i
      if h[15]=='' and h[23]!='' and h[24]=='':
        if float(h[23])<0.001:
          print >>f2,i
      if h[15]!='' and h[23]=='' and h[24]=='':
        if float(h[15])<0.001:
          print >>f2,i

f1.close()
f2.close()                                                                                                                                                                                                                                                                                                                                                                     
